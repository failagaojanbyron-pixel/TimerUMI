# Cozy Count Up Timer for Ubuntu

`CozyCountUpTimer` is a self-contained 64-bit Ubuntu/Linux executable. It does not require .NET to be installed.

## Run directly

```bash
chmod +x CozyCountUpTimer
./CozyCountUpTimer
```

## Add to the applications menu

Keep `CozyCountUpTimer` and `install-ubuntu.sh` in the same folder, then run:

```bash
chmod +x install-ubuntu.sh
./install-ubuntu.sh
```

For spoken counts and volume control, install the speech engine and an audio player:

```bash
sudo apt update
sudo apt install espeak-ng pulseaudio-utils alsa-utils
```

The app generates each spoken count as audio, applies the selected 0–300% gain, and then plays it through `paplay` (or `aplay` as a fallback). Levels over 100% can make quiet voices louder, but very high levels may distort. Ubuntu's master output volume still controls the final speaker volume.

Logs and the last operator name are stored under `~/.local/share/CountUpTimer/`.

The `Global keys` button enables or disables background A/W/S controls. The app uses a non-blocking XInput2 listener, so a keyboard or USB pedal still sends A/W/S to the active program while the timer also reacts. This works across the full desktop on an X11/Xorg session. Ubuntu Wayland restricts global single-letter monitoring; under Wayland the app can only monitor compatible X11/XWayland applications.

To use full global controls on Ubuntu, sign out, select your account, click the gear icon, choose **Ubuntu on Xorg**, and sign back in.

Keyboard controls:

- Press `S` twice to start.
- Press `W` to save a normal record and reset.
- Press `A` to save a quarantine record and reset.
- Press `R` to save a normal record and reset.
- Press `Space` to pause or resume.

Turn `Global keys` off when you do not want normal typing or pedal activity to control the timer. Other applications continue receiving A, W, and S in either mode.
