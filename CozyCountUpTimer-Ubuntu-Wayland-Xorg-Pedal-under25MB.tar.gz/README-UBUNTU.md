# Cozy Count Up Timer for Ubuntu

`CozyCountUpTimer` is a self-contained 64-bit Ubuntu/Linux executable. It does not require .NET to be installed.

## Run directly

```bash
chmod +x CozyCountUpTimer
./CozyCountUpTimer
```

## Add to the applications menu

Keep `CozyCountUpTimer` and `install-ubuntu.sh` in the same folder, then run:

```bash
chmod +x install-ubuntu.sh
./install-ubuntu.sh
```

For spoken counts and volume control, install the speech engine and an audio player:

```bash
sudo apt update
sudo apt install espeak-ng pulseaudio-utils alsa-utils
```

The app generates each spoken count as audio, applies the selected 0–300% gain, and then plays it through `paplay` (or `aplay` as a fallback). Levels over 100% can make quiet voices louder, but very high levels may distort. Ubuntu's master output volume still controls the final speaker volume.

Logs and the last operator name are stored under `~/.local/share/CountUpTimer/`.

## Background pedal controls: Wayland and Xorg

Close the timer, plug in your USB pedal, then run this once in the extracted folder as your normal desktop user:

```bash
bash ./setup-pedal.sh
```

Choose the pedal's keyboard interface from the list and confirm. The script asks for your administrator password to install a device-specific udev rule. Reopen the timer and enable `Global keys`; the button should show `Pedal: ON`. You can keep using Wayland. No input-group membership, root app, or Xorg switch is required.

The app reads A/W/S presses directly from the selected pedal using Linux evdev. It never grabs the device, so other applications continue receiving pedal keys. It ignores held-key repeats and automatically reconnects after an unplug/replug or suspend. Keep the pedal in the same USB port; rerun setup after moving it, replacing it, or changing its programmed USB interface. Pedal keys must be programmed as A/W/S; remapping them only inside another application does not change the pedal's physical key codes.

`Pedal: permission` means setup must be rerun or the desktop session must be signed out/in. `Pedal: reconnecting` means the configured device is absent; reconnect it in the original port. A USB pedal with multiple keyboard interfaces may require selecting a different interface in setup.

Without pedal setup, Xorg retains the original background keyboard controls. Wayland displays `RUN SETUP-PEDAL.SH` instead of claiming that restricted XWayland monitoring works everywhere. With pedal setup, only the selected device controls the timer in the background; ordinary keyboard shortcuts still work while the timer is focused.

This package targets x86-64 Ubuntu desktops with direct access to `/dev/input` and udev/systemd-logind (including GNOME Wayland, GNOME Xorg, and other desktop environments using these services). Sandboxed Snap/Flatpak sessions, remote desktops without a locally attached pedal, containers, ARM systems, and a locked/inactive desktop session are not covered by this package. No application can bypass every Ubuntu security/session configuration automatically.

To remove pedal permission, close the timer and run:

```bash
sudo rm /etc/udev/rules.d/70-cozy-count-up-pedal.rules
sudo udevadm control --reload-rules
```

Then unplug/replug the pedal. Logs are unaffected. Setup grants the active local desktop session read access to the selected input interface; choose the pedal rather than your normal keyboard.

Keyboard controls:

- Press `S` twice to start.
- Press `W` to save a normal record and reset.
- Press `A` to save a quarantine record and reset.
- Press `R` to save a normal record and reset.
- Press `Space` to pause or resume.

Turn `Global keys` off when you do not want normal typing or pedal activity to control the timer. Other applications continue receiving A, W, and S in either mode.
