#!/usr/bin/env bash
set -euo pipefail

# Run as the desktop user. Only installation of the device rule needs sudo.
if [[ ${EUID} -eq 0 ]]; then
  echo "Run ./setup-pedal.sh as your normal desktop user, without sudo."
  exit 1
fi
for tool in udevadm sudo install readlink; do
  command -v "${tool}" >/dev/null || { echo "Missing requirement: ${tool}"; exit 1; }
done

echo "Connect your USB pedal. Select its keyboard interface below."
echo "This grants your desktop session access only to the selected USB device/port."
shopt -s nullglob
devices=()
for node in /dev/input/event*; do
  properties="$(udevadm info --query=property --name="${node}" 2>/dev/null || true)"
  if [[ ( "${properties}" == *"ID_INPUT_KEYBOARD=1"* || "${properties}" == *"ID_INPUT_KEY=1"* ) && "${properties}" == *"ID_BUS=usb"* ]]; then
    devices+=("${node}")
    label="$(<"/sys/class/input/${node##*/}/device/name")"
    printf '%d) %s (%s)\n' "${#devices[@]}" "${label}" "${node}"
  fi
done
if (( ${#devices[@]} == 0 )); then
  echo "No USB keyboard/pedal interfaces found. Connect a pedal programmed to send A, W, and S."
  exit 1
fi
read -r -p "Pedal number (or Ctrl+C to cancel): " choice
if [[ ! "${choice}" =~ ^[0-9]{1,3}$ ]] || (( 10#${choice} < 1 || 10#${choice} > ${#devices[@]} )); then
  echo "Invalid selection. No changes made."
  exit 1
fi
node="${devices[$((10#${choice} - 1))]}"
properties="$(udevadm info --query=property --name="${node}")"
device_path=""
vendor_id=""
product_id=""
for property in ${properties}; do
  case "${property}" in
    ID_PATH=*) device_path="${property#ID_PATH=}" ;;
    ID_VENDOR_ID=*) vendor_id="${property#ID_VENDOR_ID=}" ;;
    ID_MODEL_ID=*) product_id="${property#ID_MODEL_ID=}" ;;
  esac
done
# ID_PATH includes the USB port and interface. A literal match avoids granting
# access to other keyboards, including identical devices on other ports.
if [[ -z "${device_path}" || ! "${device_path}" =~ ^[a-zA-Z0-9_.:+-]+$ || ! "${vendor_id}" =~ ^[a-fA-F0-9]{4}$ || ! "${product_id}" =~ ^[a-fA-F0-9]{4}$ ]]; then
  echo "Cannot identify a stable USB path for this device. No changes made."
  exit 1
fi
label="$(<"/sys/class/input/${node##*/}/device/name")"
printf '\nSelected: %s at %s\n' "${label}" "${device_path}"
echo "Keep the pedal in this USB port. Run setup again if you move it."
read -r -p "Allow this device for background timer controls? [y/N] " answer
[[ "${answer}" == "y" || "${answer}" == "Y" ]] || exit 0

rule_temp="$(mktemp)"
trap 'rm -f -- "${rule_temp}"' EXIT
printf '%s\n' '# Cozy Count Up Timer: selected pedal only, active local desktop user.' > "${rule_temp}"
printf 'SUBSYSTEM=="input", KERNEL=="event*", ENV{ID_BUS}=="usb", ENV{ID_VENDOR_ID}=="%s", ENV{ID_MODEL_ID}=="%s", ENV{ID_PATH}=="%s", TAG+="uaccess", SYMLINK+="input/cozy-count-up-pedal"\n' "${vendor_id}" "${product_id}" "${device_path}" >> "${rule_temp}"
sudo install -o root -g root -m 644 "${rule_temp}" /etc/udev/rules.d/70-cozy-count-up-pedal.rules
sudo udevadm control --reload-rules
sudo udevadm trigger --action=change "/sys/class/input/${node##*/}"
sudo udevadm settle
if [[ -r /dev/input/cozy-count-up-pedal ]]; then
  echo "Pedal configured. Reopen the timer and enable Global keys. It should show Pedal: ON."
else
  echo "Rule installed. Unplug/replug the pedal in the SAME USB port, then reopen the timer."
  echo "If permission is still unavailable, sign out and sign back in, then retry."
fi
echo "The pedal continues sending keys to other applications. Do not run the timer with sudo."
