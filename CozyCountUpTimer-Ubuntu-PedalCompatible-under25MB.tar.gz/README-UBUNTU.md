# Cozy Count Up Timer for Ubuntu

`CozyCountUpTimer` is a self-contained 64-bit Ubuntu/Linux executable. It does not require .NET to be installed.

## Run directly

```bash
chmod +x CozyCountUpTimer
./CozyCountUpTimer
```

## Add to the applications menu

Keep `CozyCountUpTimer` and `install-ubuntu.sh` in the same folder, then run:

```bash
chmod +x install-ubuntu.sh
./install-ubuntu.sh
```

For spoken counts, install the Ubuntu speech engine:

```bash
sudo apt update
sudo apt install espeak-ng
```

Logs and the last operator name are stored under `~/.local/share/CountUpTimer/`.

The `Global keys` button enables or disables background A/W/S controls. The app uses a non-blocking XInput2 listener, so a keyboard or USB pedal still sends A/W/S to the active program while the timer also reacts. This works across the full desktop on an X11/Xorg session. Ubuntu Wayland restricts global single-letter monitoring; under Wayland the app can only monitor compatible X11/XWayland applications.

To use full global controls on Ubuntu, sign out, select your account, click the gear icon, choose **Ubuntu on Xorg**, and sign back in.

Keyboard controls:

- Press `S` twice to start.
- Press `W` to save a normal record and reset.
- Press `A` to save a quarantine record and reset.
- Press `R` to save a normal record and reset.
- Press `Space` to pause or resume.

Turn `Global keys` off when you do not want normal typing or pedal activity to control the timer. Other applications continue receiving A, W, and S in either mode.
