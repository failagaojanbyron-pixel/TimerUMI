# Cozy Count Up Timer for Ubuntu

`CozyCountUpTimer` is a self-contained 64-bit Ubuntu/Linux executable. It does not require .NET to be installed.

## Run directly

```bash
chmod +x CozyCountUpTimer
./CozyCountUpTimer
```

## Add to the applications menu

Keep `CozyCountUpTimer` and `install-ubuntu.sh` in the same folder, then run:

```bash
chmod +x install-ubuntu.sh
./install-ubuntu.sh
```

For spoken counts and volume control, install the speech engine and an audio player:

```bash
sudo apt update
sudo apt install espeak-ng pulseaudio-utils alsa-utils
```

The app generates each spoken count as audio, applies the selected 0–300% gain, and then plays it through `paplay` (or `aplay` as a fallback). Levels over 100% can make quiet voices louder, but very high levels may distort. Ubuntu's master output volume still controls the final speaker volume.

Logs and the last operator name are stored under `~/.local/share/CountUpTimer/`.

## Background pedal controls: Wayland and Xorg

Connect your USB pedal and open the app. When Global keys is enabled, the app scans for USB pedals at startup and when a device is connected. No terminal command or external setup script is required.

The app automatically selects a clearly named pedal in the permission window. Click **Enable pedal**, then approve Ubuntu's graphical administrator prompt once. If Ubuntu gives your pedal a generic name, choose it from the detected USB devices. The app does not assume that your ordinary keyboard is the pedal.

The button should show **Pedal: ON** after approval. The permission helper is embedded in the executable, so copying only the app is sufficient. Previously granted permission is reused without another prompt. Cancelling the permission window stops automatic prompts until you click **Detect pedal**, turn Global keys back on, or reopen the app. Turning Global keys off also disables automatic discovery and background pedal input.

The app reads A/W/S presses directly from the selected pedal using Linux evdev. It never grabs the device, so other applications continue receiving pedal keys. It ignores held-key repeats and automatically reconnects after an unplug/replug or suspend. After moving it to a different USB port or replacing it, use **Detect pedal** if it is not recognized automatically; Ubuntu may ask you to approve the new device/port. Pedal keys must be programmed as A/W/S; remapping them only inside another application does not change the pedal's physical key codes.

`Pedal: permission` means access must be approved using **Detect pedal**. `Pedal: reconnecting` means the configured device is absent; reconnect it or select it again. A USB pedal with multiple keyboard interfaces may require choosing a different interface from the detected list. If approval succeeds but permission is not immediately applied, unplug/replug once, or sign out/in.

Xorg retains the original background keyboard controls until a pedal is configured. Wayland uses the selected pedal for full background controls after approval. Ordinary keyboard shortcuts still work while the timer is focused.

This package targets x86-64 Ubuntu desktops with direct access to `/dev/input`, udev/systemd-logind, and pkexec with a graphical authentication agent (as provided by standard Ubuntu desktops). GNOME Wayland and Xorg are supported. Sandboxed Snap/Flatpak sessions, remote desktops without a locally attached pedal, containers, ARM systems, and a locked/inactive desktop session are not covered by this package.

To remove pedal permission, close the timer and run:

```bash
sudo rm /etc/udev/rules.d/70-cozy-count-up-pedal.rules
sudo udevadm control --reload-rules
```

Then unplug/replug the pedal. Logs are unaffected. Setup grants the active local desktop session read access to the selected input interface; choose the pedal rather than your normal keyboard.

Keyboard controls:

- Press `S` twice to start.
- Press `W` to save a normal record and reset.
- Press `A` to save a quarantine record and reset.
- Press `R` to save a normal record and reset.
- Press `Space` to pause or resume.

Turn `Global keys` off when you do not want normal typing or pedal activity to control the timer. Other applications continue receiving A, W, and S in either mode.
