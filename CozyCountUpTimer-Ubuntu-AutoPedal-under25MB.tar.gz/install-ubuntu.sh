#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${HOME}/.local/opt/cozy-count-up-timer"
DESKTOP_DIR="${HOME}/.local/share/applications"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "${APP_DIR}" "${DESKTOP_DIR}"
install -m 755 "${SCRIPT_DIR}/CozyCountUpTimer" "${APP_DIR}/CozyCountUpTimer"
if [[ -f "${SCRIPT_DIR}/setup-pedal.sh" ]]; then
  install -m 755 "${SCRIPT_DIR}/setup-pedal.sh" "${APP_DIR}/setup-pedal.sh"
fi

cat > "${DESKTOP_DIR}/cozy-count-up-timer.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Cozy Count Up Timer
Comment=Operator count-up timer with voice and quarantine logs
Exec=${APP_DIR}/CozyCountUpTimer
Terminal=false
Categories=Utility;
EOF

if ! command -v espeak-ng >/dev/null 2>&1 && ! command -v spd-say >/dev/null 2>&1; then
  echo "Voice support needs espeak-ng. Install it with: sudo apt install espeak-ng"
fi

echo "Installed Cozy Count Up Timer. Open it from your applications menu."
echo "The app detects USB pedals automatically. Approve Ubuntu's one-time permission prompt if asked."
echo "Use the app's Detect pedal button to retry or change devices. No terminal setup is needed."
